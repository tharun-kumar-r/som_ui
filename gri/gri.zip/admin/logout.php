<?php
include "../include/@config-domain.php";
session_destroy();
echo "<script>window.location='../';</script>";
?>