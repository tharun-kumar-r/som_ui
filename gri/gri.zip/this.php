<html>
	<head>

	<style>
*{
	padding:0px;
	margin:0px;
}
html,body{
	height:90%;
	place-items:center;
	align-items:center;
	display:grid;
}
</style>
    </head>
	<link rel="icon" type="image/png" href="./img/123.png" />
    
<body><center>
<div class="contain">
<?php include "include/brand_name.php"; ?>

<div style="margin:10px;">
<font class="sign">Grievance Option's</font><br>
</div>
	<div class="fx1">
<font color="#4b4b4b" size="2">Student, Staff, Public, Admin login option</font>
	</div>
	<br>
<div style="margin:10px;">
<div style="margin:10px;">
<input type="button" onclick="window.location='start';" class="btnblue" value="REGISTER A GRIEVANCE">
</div>
<input type="button" onclick="window.location='student-login';" class="btnwhite" value="GENERAL LOGIN">
</div>
<div style="margin:10px;">
<input type="button" onclick="window.location='admin';" class="btnwhite" value="ADMIN LOGIN">
</div>



</div>
<br>
<?php include "include/down.php"; ?>




